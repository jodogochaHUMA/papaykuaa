# Plantilla PAPAPYKUAA - Artículo v1.0

Plantilla LaTeX basada en el documento oficial tipo artículo del 2° Congreso Nacional de Educación Matemática "PAPAPYKUAA".

## Archivos

- `articulo_PAPAPYKUAA_v1_0.tex`: archivo principal editable.
- `papapykuua-articulo.cls`: clase con todo el formato del Congreso.
- `referencias.bib`: base bibliográfica de ejemplo.
- `figuras/logo_papapykuua.png`: logo utilizado en el encabezado.
- `figuras/grafico_ejemplo.png`: figura de ejemplo tomada del modelo proporcionado.

## Compilación

La plantilla requiere XeLaTeX y Biber:

```bash
xelatex articulo_PAPAPYKUAA_v1_0.tex
biber articulo_PAPAPYKUAA_v1_0
xelatex articulo_PAPAPYKUAA_v1_0.tex
xelatex articulo_PAPAPYKUAA_v1_0.tex
```

## Tipografía

El documento original exige Times New Roman. La clase utiliza:

1. Times New Roman, si está disponible.
2. Tinos, como alternativa métricamente compatible.
3. TeX Gyre Termes, como último respaldo multiplataforma.

## Requisitos reproducidos del modelo

- Formato A4.
- Cuerpo general: 11 pt, justificado, interlineado 1.0.
- Resumen: título 11 pt en negrita; texto 10 pt en cursiva; 200-400 palabras.
- Palabras clave: 10 pt en cursiva; entre 3 y 5 términos o frases.
- Secciones numeradas en mayúsculas.
- Tablas: título superior, cuerpo 9.5 pt, fuente 9 pt.
- Figuras: leyenda inferior, fuente 9 pt.
- Ecuaciones: centradas y numeradas consecutivamente.
- Referencias: 11 pt, interlineado sencillo, sangría francesa de 0.8 cm.
- Extensión total indicada por el modelo: 4 a 10 páginas.

## Nota sobre bibliografía

La clase utiliza `biblatex` + Biber con esquema autor-fecha y una presentación próxima a APA. Si el sistema dispone del paquete `biblatex-apa`, puede sustituirse `style=authoryear` por `style=apa` dentro de la clase para una implementación APA 7 completa.
