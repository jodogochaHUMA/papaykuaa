PLANTILLA PAPAPYKUAA POSTER - v1.0
Adaptación LaTeX/BeamerPoster: Blás Benítez Cristaldo
Formato: 90 x 120 cm, orientación vertical
Compilador: XeLaTeX
Gestor bibliográfico: Biber

NOVEDADES v1.0
- Mantiene la tipografía sans serif multiplataforma tipo Arial.
- Permite utilizar ambientes estándar de LaTeX/Beamer para figuras y tablas.
- Se incorporan booktabs, tabularx y estilos de caption adaptados al póster.
- Se incorpora biblatex con estilo APA y backend Biber.
- Las citas pueden escribirse con \textcite{}, \parencite{}, etc.
- La bibliografía se genera automáticamente con \PosterReferenciasBib.
- Incluye un archivo referencias.bib de ejemplo.
- Incluye ejemplos de figure, table, referencias cruzadas y citas APA.

ESTRUCTURA DEL PROYECTO
- poster_PAPAPYKUAA.tex
  Archivo principal y contenido editable del póster.

- beamerthemePAPAPYKUAAposter.sty
  Diseño, posiciones, tipografía, captions y áreas del póster.

- referencias.bib
  Base bibliográfica BibLaTeX/Biber.

- figuras/
  Logos y figuras de ejemplo. Las figuras de ejemplo pueden reemplazarse
  por archivos PNG, JPG o PDF del estudio.

- Vista_Previa_PAPAPYKUAA_Poster_v1_0.pdf
  Ejemplo compilado del proyecto.

AMBIENTE FIGURE
Ejemplo:

\PosterObjetivosVisual{%
  \begin{figure}
    \centering
    \includegraphics[width=.88\linewidth]{figuras/mi_figura.png}
    \caption{Descripción de la figura.}
    \label{fig:ejemplo}
  \end{figure}
}

AMBIENTE TABLE
Ejemplo:

\PosterSuperiorTabla{%
  \begin{table}
    \centering
    \caption{Resultados principales}
    \label{tab:resultados}
    \begin{tabular}{lcc}
      \toprule
      Nivel & f & \% \\
      \midrule
      Alto & 18 & 30 \\
      Medio & 27 & 45 \\
      Bajo & 15 & 25 \\
      \bottomrule
    \end{tabular}
  \end{table}
}

CITAS
- Narrativa: \textcite{hernandez2014}
- Parentética: \parencite{hernandez2014}
- Con página: \parencite[p.~35]{hernandez2014}

REFERENCIAS
El archivo principal contiene:

\addbibresource{referencias.bib}

Y la zona final del póster utiliza:

\PosterReferenciasBib

Solo se imprimen las fuentes citadas. Para imprimir toda la base puede
agregarse \nocite{*} antes de \PosterReferenciasBib.

COMPILACIÓN
En TeXstudio se recomienda configurar:
- Compilador: XeLaTeX
- Bibliografía: Biber

FUENTES
Cadena automática de compatibilidad:
Arimo -> Arial -> Liberation Sans -> Latin Modern Sans.

TÉRMINOS DE DISTRIBUCIÓN
Se permite utilizar, modificar y redistribuir esta plantilla para fines
académicos, manteniendo la referencia a Blás Benítez Cristaldo como autor
de la adaptación LaTeX/BeamerPoster. Los logotipos, marcas y elementos
institucionales pertenecen a sus respectivos titulares.
